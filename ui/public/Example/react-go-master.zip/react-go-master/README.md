react-go
========

The game of [Go][1] implemented with [React][2]. Check out a [live preview][3] or [read the tutorial][4]

[1]: http://en.wikipedia.org/wiki/Go_(game)
[2]: http://facebook.github.io/react/
[3]: http://cjlarose.com/react-go/ 
[4]: http://cjlarose.com/2014/01/09/react-board-game-tutorial.html
